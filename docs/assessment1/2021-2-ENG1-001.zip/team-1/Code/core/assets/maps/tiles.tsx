<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="tiles" tilewidth="64" tileheight="64" tilecount="9" columns="3">
 <image source="tiles.png" width="192" height="192"/>
 <tile id="1">
  <properties>
   <property name="college" value="constantine"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="college" value="langwith"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="traversable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="traversable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="college" value="goodricke"/>
  </properties>
 </tile>
</tileset>
