package main.game.enums;

public enum GameState {
    READY, RUNNING, PAUSED;
}
