package main.game;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import main.game.world.World;
import main.game.world.content.College;
import main.game.world.player.Player;
import main.game.world.player.Objectives.Objective;
import main.game.world.player.Objectives.ObjectiveManager;

import org.junit.runner.RunWith;

import com.badlogic.gdx.math.Vector2;


@RunWith(GdxTestRunner.class)
public class CollisionTest {

	private World world;
	
	@Before
	public void setUp() throws Exception {
		world= new World(true);
	}

	@After
	public void tearDown() throws Exception {
		world.dispose();
		world = null;
	}

	@Test
	public void collisionDamageCollege() {
		
		Player player = world.getPlayer();
		assertEquals("player has default health",player.getHealth(),100);
		
		
		player.setPosition((float)4000.0, (float)4500.0);
		
		//add x + 16 and y + 32 to get centre 
		Vector2 position = new Vector2(4016,4532);
		assertEquals("player position",player.getPosition(),position);
		world.worldCycle();
		assertEquals("collision damage",player.getHealth(),90);
		
	}
	
	@Test
	public void collisionDamageAlliedCollege() {
		
		Player player = world.getPlayer();
		assertEquals("player has default health",player.getHealth(),100);
		
		
		player.setPosition((float)1000.0, (float)1300.0);
		
		//add x + 16 and y + 32 to get centre 
		Vector2 position = new Vector2(1016,1332);
		assertEquals("player position",player.getPosition(),position);
		world.worldCycle();
		assertEquals("collision damage",player.getHealth(),90);
		
	}
	
	@Test
	public void collisionDamageNPC() {
		
		Player player = world.getPlayer();
		assertEquals("player has default health",player.getHealth(),100);
		
		
		player.setPosition((float)3600.0, (float)3750.0);
		
		//add x + 16 and y + 32 to get centre 
		Vector2 position = new Vector2(3616,3782);
		assertEquals("player position",player.getPosition(),position);
		world.worldCycle();
		assertEquals("collision damage",player.getHealth(),90);
		
	}

}
