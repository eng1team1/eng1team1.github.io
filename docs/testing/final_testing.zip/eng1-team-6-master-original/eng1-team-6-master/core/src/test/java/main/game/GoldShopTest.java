package main.game;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.game.GdxTestRunner;
import main.game.world.World;
import main.game.world.player.Player;
import main.game.world.player.Objectives.Objective;

import org.junit.runner.RunWith;


@RunWith(GdxTestRunner.class)
public class GoldShopTest {

	private World world;

	@Before
	public void setUp() throws Exception {
		world= new World(true);

	}

	@After
	public void tearDown() throws Exception {
		world.dispose();
		world = null;
	}

	@Test
	public void playerInitialTest() {
		Player player = world.getPlayer();
		assertNotNull(player);

	}
}