package main.game;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import main.game.world.World;
import main.game.world.player.Player;
import main.game.world.player.Objectives.Objective;

import org.junit.runner.RunWith;


@RunWith(GdxTestRunner.class)
public class PlayerTesting {

	private World world;

	@Before
	public void setUp() throws Exception {
		world= new World(true);

	}

	@After
	public void tearDown() throws Exception {
		world.dispose();
		world = null;
	}

	@Test
	public void playerInitialTest() {
		Player player = world.getPlayer();
		assertNotNull(player);
		assertEquals(player.getHealth(),100); // TODO
		assertEquals(player.getDamage(),100);
		assertEquals(player.getGold(),0);
		assertEquals(player.getScore(),0);
		assertEquals(player.getWon(),false);
		world.worldCycle();
		//assertEquals("objectives loaded in", player.getObjectives().size() ,8);
		assertEquals("colleges loaded in", world.getColleges().size() ,4);
		assertEquals("npcs loaded in", world.getNPCs().size() ,20);
		assertEquals("obstacles loaded in", world.getObstacles().size() ,3);
		
		
	}
	
	@Test
	public void playerObjective1to2() {
		Player player = world.getPlayer();
		player.updateObjective("move", 100);
		player.updateObjective("move", 151);
		int[] nxp = player.getLevelNXP(); 
		assertEquals("current level",nxp[0],1); 
		assertEquals("xp",nxp[1],1);
		assertEquals("next level xp",nxp[2],3);
		assertEquals(player.getWon(),false);
		Objective objective= player.getCurrentObjective();
		assertEquals(objective.getuKey(),"shoot");
	}
	
	
	@Test
	public void playerSkipObjectiveTest() {
		Player player = world.getPlayer();
		player.updateObjective("shoot", 100);
		int[] nxp = player.getLevelNXP(); 
		assertEquals("current level",nxp[0],1); //{currentLevel, xp, nextLevelXP}
		assertEquals("xp",nxp[1],0);
		assertEquals("next level xp",nxp[2],3);
		assertEquals(player.getWon(),false);
	}
	
	@Test
	public void playerObjective2to3() {
		Player player = world.getPlayer();
		player.updateObjective("move", 100);
		player.updateObjective("move", 151);
		int[] nxp = player.getLevelNXP(); 
		assertEquals("current level",nxp[0],1); 
		assertEquals("xp",nxp[1],1);
		assertEquals("next level xp",nxp[2],3);
		assertEquals(player.getWon(),false);
		Objective objective= player.getCurrentObjective();
		assertEquals(objective.getuKey(),"shoot");
		
		
		player.updateObjective("shoot", 100);
		nxp = player.getLevelNXP(); 
		assertEquals("o2 current level ",nxp[0],1); 
		assertEquals("o2 xp",nxp[1],2);
		assertEquals("o2 next level xp",nxp[2],3);
		Objective objective2= player.getCurrentObjective();
		assertEquals(objective2.getuKey(),"npc");
		
		player.updateObjective("npc", 100);
		nxp = player.getLevelNXP(); 
		assertEquals("o3 current level ",nxp[0],2); 
		assertEquals("o3 xp",nxp[1],4);
		assertEquals("o3 next level xp",nxp[2],8);
	}

}

