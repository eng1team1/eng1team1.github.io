/**
 * 
 */
package main.game;

import static org.junit.Assert.*;
import java.util.*; 
import java.util.Set;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import main.game.world.World;
import main.game.world.content.College;

import main.game.world.player.Player;

import org.junit.runner.RunWith;

import com.badlogic.gdx.math.Vector2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Dave

 *
 */
@RunWith(GdxTestRunner.class)
public class CollegeTesting {
	private World world;


	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		world= new World(true);

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		world.dispose();
		world = null;
	}

	@Test
	public void collegeDamage() {
		//initialising a generic college
		int health =100;
		int damage = 100;
		String name = "test";
		String ukey = "college-test";
		Vector2 position = new Vector2(0, 0);
		boolean allied = false;
		College college = new College( health,  damage,  name,  ukey,  position,  allied); 
		assertNotNull(college);
		college.takeDamage(10);
		assertEquals("college takes damage",college.getHealth(),90);
		college.setAllied();
		college.takeDamage(10000);
		assertEquals("no damage taken when immune", college.getHealth(),90);
		
	}
	
	@Test
	public void collegeCapture() {
		Player player = world.getPlayer();
		player.setPosition((float)4100.0, (float)4600.0);
		Set<College> allColleges = world.getColleges();
		List<College> allCollegesList = new ArrayList<College>(allColleges); 
		College c1 = allCollegesList.get(0);
		
		for (College college : allColleges) { 
			
			if (college.getName().equals("LANGWITH")) {
			
				assertEquals("name is right",college.getName(),"LANGWITH");
				assertEquals("health is correct",college.getHealth(),3000);
				assertEquals("damage is correct",college.getDamage(),75);
				
				college.takeDamage(1000);
				assertEquals("college takes damage",college.getHealth(),2000);
				college.takeDamage(1000000);
				break;
			}
		}
		
		world.worldCycle();

		
		for (College college : allColleges) { 
			
			if (college.getName().equals("LANGWITH")) {
				c1 = college;
				break;
			}
		}
		

		assertEquals(c1.getAllied() ,true);
		
	}

}